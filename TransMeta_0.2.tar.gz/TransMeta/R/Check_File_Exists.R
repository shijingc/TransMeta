Check_File_Exists <-
function(FileName){

if(!file.exists(FileName)){
Msg<-sprintf("File %s does not exist\n",FileName)
stop(Msg)
}

}
