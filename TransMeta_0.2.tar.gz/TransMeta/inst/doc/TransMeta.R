### R code from vignette source 'TransMeta.Rnw'
### Encoding: ISO8859-1

###################################################
### code chunk number 1: data
###################################################
library(TransMeta)
File.Name <- c("Data_1.txt", "Data_2.txt", "Data_3.txt",
"Data_4.txt", "Data_5.txt", "Data_6.txt", 
"Ancestry_Group.txt")
n.study <- length(File.Name)-1
objects <- list()
for (i in 1:n.study) {
	objects[[i]] <- read.table(File.Name[i],header = TRUE)
	colnames(objects[[i]]) <- c("SNP", "N", "Test_Allele","Alt_Allele", 
"MAF", "Beta", "SE", "P_Val")	
}
head(objects[[1]])
head(objects[[n.study]])

Population.Id <- read.table(File.Name[n.study+1])
Population.Id


###################################################
### code chunk number 2: SKAT1
###################################################
# the genetic similarity kernel structure 
get_K_Fst(File.Name)

# the group-wise independent kernel structure
get_K_indep(File.Name)



###################################################
### code chunk number 3: SKAT11
###################################################
# To run this code, first download and unzip example files

##############################################
# 	the group-wise kernel structure


a1=Get_TransMeta(FileName = File.Name, K.type = "Indep" )
head(a1)



##############################################
# 	the genetic similarity kernel structure, where F.st is 
# estimated from HapMap 3 Consortium 




###################################################
### code chunk number 4: SKAT12
###################################################
a2=Get_TransMeta(FileName = File.Name, K.type = "Fst", K = get_K_Fst(File.Name))
head(a2)


##############################################
# 	the genetic similarity kernel structure, where F.st is 
# estimated from the input data




###################################################
### code chunk number 5: SKAT13
###################################################
a3=Get_TransMeta(FileName = File.Name, K.type = "Fst")
head(a3)


